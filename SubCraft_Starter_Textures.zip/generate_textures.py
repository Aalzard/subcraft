#!/usr/bin/env python3
"""Original procedural SubCraft starter textures. No external image inputs.

Install: python -m pip install numpy Pillow scipy
Run:     python generate_textures.py --size 1024
All coordinates use UV units, and all randomness has a fixed per-texture seed.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import time

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy.ndimage import gaussian_filter, map_coordinates
from scipy.spatial import cKDTree


def grid(n):
    """Pixel-centered coordinates, broadcast instead of allocating two grids."""
    a = (np.arange(n, dtype=np.float32) + .5) / n
    return a[None, :], a[:, None]


def smoothstep(a, b, v):
    t = np.clip((v - a) / (b - a), 0, 1)
    return t * t * (3 - 2 * t)


def noise(n, frequency, seed):
    """Cubic random lattice on a torus; periodic value AND derivative."""
    rng = np.random.default_rng(seed)
    lattice = rng.standard_normal((frequency, frequency)).astype(np.float32)
    axis = (np.arange(n, dtype=np.float32) + .5) * frequency / n
    out = np.empty((n, n), np.float32)
    for start in range(0, n, 128):
        stop = min(n, start + 128)
        coordinates = np.array(np.broadcast_arrays(axis[start:stop, None], axis[None, :]))
        out[start:stop] = map_coordinates(lattice, coordinates, order=3, mode='grid-wrap')
    return out


def fbm(n, seed, frequencies=(8, 16, 32, 64), decay=.5):
    out = np.zeros((n, n), np.float32)
    for i, frequency in enumerate(frequencies):
        out += decay ** i * noise(n, frequency, seed + 101 * i)
    return out


def wrap_delta(v):
    return (v + .5) % 1 - .5


def brick(n):
    """Running bond, recessed mortar, independent brick relief and chipped lips."""
    x, y = grid(n)
    row = np.floor(y * 8).astype(np.int32)
    u = (x * 4 + .5 * (row % 2)) % 1
    v = (y * 8) % 1
    edge = np.minimum(np.minimum(u, 1 - u) / 4, np.minimum(v, 1 - v) / 8)
    damage = np.maximum(noise(n, 82, 1101) - .35, 0) * .0028
    lip = smoothstep(.0045, .012, edge - damage)
    col = np.floor(x * 4 + .5 * (row % 2)).astype(np.int32) % 4
    variation = np.random.default_rng(1102).uniform(.86, 1.12, (8, 4)).astype(np.float32)[row, col]
    face = .84 + .045 * fbm(n, 1103, (28, 56, 112))
    return gaussian_filter(lip * face * variation, .0006 * n, mode='wrap')


def cobblestone(n):
    """Jittered periodic Voronoi stones, rounded crowns and irregular grout."""
    rng = np.random.default_rng(2201)
    points = np.array([((c + .5 + rng.uniform(-.3, .3)) / 8,
                        (r + .5 + rng.uniform(-.3, .3)) / 8)
                       for r in range(8) for c in range(8)], np.float32)
    tree = cKDTree(points, boxsize=1.)
    x, y = grid(n)
    warp_x = .006 * noise(n, 24, 2202)
    warp_y = .006 * noise(n, 24, 2203)
    heights = rng.uniform(.87, 1.13, 64).astype(np.float32)
    out = np.empty((n, n), np.float32)
    for start in range(0, n, 128):
        stop = min(start + 128, n)
        xx = (np.broadcast_to(x, (stop - start, n)) + warp_x[start:stop]) % 1
        yy = (np.broadcast_to(y[start:stop], (stop - start, n)) + warp_y[start:stop]) % 1
        d, ids = tree.query(np.column_stack((xx.ravel(), yy.ravel())), k=2)
        margin = (d[:, 1] - d[:, 0]).reshape(stop - start, n)
        crown = np.exp(-2.8 * (d[:, 0] / .10) ** 2).reshape(stop - start, n)
        out[start:stop] = smoothstep(.005, .021, margin) * (.62 + .38 * crown) * heights[ids[:, 0]].reshape(stop - start, n)
    out += .018 * fbm(n, 2204, (40, 80, 160)) * smoothstep(.1, .5, out)
    return gaussian_filter(out, .0007 * n, mode='wrap')


def hex_tiles(n):
    """Staggered hexagon tessellation; 7 columns/8 rows fit a square torus."""
    x, y = grid(n)
    xx, yy = x * 7, y * 8 * np.float32(np.sqrt(3) / 2)
    base_row = np.floor(y * 8).astype(np.int32)
    best = np.full((n, n), np.inf, np.float32)
    chosen_x = np.zeros_like(best)
    chosen_y = np.zeros_like(best)
    variation = np.zeros_like(best)
    rng = np.random.default_rng(3301)
    relief = rng.uniform(.93, 1.07, (8, 7)).astype(np.float32)
    for offset in (-1, 0, 1):
        row = base_row + offset
        shift = (row % 2) * .5
        col = np.floor(xx - shift + .5).astype(np.int32)
        dx = xx - (col + shift)
        dy = yy - row * np.float32(np.sqrt(3) / 2)
        distance = dx * dx + dy * dy
        take = distance < best
        chosen_x = np.where(take, dx, chosen_x)
        chosen_y = np.where(take, dy, chosen_y)
        variation = np.where(take, relief[row % 8, col % 7], variation)
        best = np.minimum(best, distance)
    edge = .5 - np.maximum.reduce([np.abs(chosen_x),
            np.abs(.5 * chosen_x + np.float32(np.sqrt(3) / 2) * chosen_y),
            np.abs(.5 * chosen_x - np.float32(np.sqrt(3) / 2) * chosen_y)])
    lip = smoothstep(.021, .064, edge)
    wear = .009 * noise(n, 124, 3302) + .012 * noise(n, 35, 3303)
    return lip * (variation + wear)


def leather(n):
    """Fine cellular grain, pores and softly meandering wrinkles."""
    x, y = grid(n)
    rng = np.random.default_rng(4401)
    points = np.array([((c + .5 + rng.uniform(-.35, .35)) / 54,
                        (r + .5 + rng.uniform(-.35, .35)) / 54)
                       for r in range(54) for c in range(54)], np.float32)
    tree = cKDTree(points, boxsize=1.)
    grain = np.empty((n, n), np.float32)
    for start in range(0, n, 128):
        stop = min(start + 128, n)
        xx, yy = np.broadcast_arrays(x, y[start:stop])
        distance, _ = tree.query(np.column_stack((xx.ravel(), yy.ravel())), k=2)
        margin = (distance[:, 1] - distance[:, 0]).reshape(stop - start, n)
        crown = np.exp(-(distance[:, 0] / .012) ** 2).reshape(stop - start, n)
        grain[start:stop] = .10 * smoothstep(.0003, .0034, margin) + .025 * crown
    pores = np.maximum(noise(n, 245, 4402) - .8, 0)
    warp = .016 * noise(n, 9, 4403)
    wrinkles = np.exp(-((np.sin(2 * np.pi * (x * 7 + y * 4 + warp * 18))) / .14) ** 2)
    return grain - .022 * pores - .03 * wrinkles + .004 * noise(n, 160, 4404)


def fabric_weave(n):
    """Alternating top threads at intersections, cylindrical yarn, fine fibers."""
    x, y = grid(n)
    u, v = x * 28, y * 28
    du, dv = (u + .5) % 1 - .5, (v + .5) % 1 - .5
    vertical = np.exp(-(du / .32) ** 4)
    horizontal = np.exp(-(dv / .32) ** 4)
    # Lift and lower threads smoothly as they pass through successive crossings.
    wave = np.cos(np.pi * u) * np.cos(np.pi * v)
    h = np.maximum(vertical * (.64 + .21 * wave), horizontal * (.64 - .21 * wave))
    fibers = .045 * (vertical * np.cos(2 * np.pi * u * 5) + horizontal * np.cos(2 * np.pi * v * 5))
    return h + fibers + .008 * noise(n, 150, 5501)


def diamond_plate(n):
    """Alternating diagonal, raised, rounded metal lozenges."""
    x, y = grid(n)
    u, v = x * 8, y * 8
    cx, cy = (u + .5) % 1 - .5, (v + .5) % 1 - .5
    parity = (np.floor(u + .5).astype(np.int32) + np.floor(v + .5).astype(np.int32)) % 2
    direction = 1 - 2 * parity
    along = (cx + direction * cy) / np.sqrt(2)
    across = (cx - direction * cy) / np.sqrt(2)
    diamond = np.abs(along) / .40 + np.abs(across) / .10
    return .85 * (1 - smoothstep(.73, 1.03, diamond)) + .003 * noise(n, 96, 6601)


def concrete(n):
    """Multiscale aggregate roughness and rounded small air holes."""
    h = .085 * fbm(n, 7701, (18, 36, 72, 144), .55)
    pits = np.maximum(noise(n, 78, 7702) - .50, 0)
    h -= .10 * smoothstep(0, 1.2, pits)
    x, y = grid(n)
    rng = np.random.default_rng(7703)
    for _ in range(100):
        px, py = rng.random(2)
        radius = rng.uniform(.003, .014)
        rr = (wrap_delta(x - px) ** 2 + wrap_delta(y - py) ** 2) / radius ** 2
        h -= rng.uniform(.08, .21) * np.maximum(1 - rr, 0) ** 2
    return h


def wood_planks(n):
    """Vertical timber, wandering grain, closed knot rings and recessed joints."""
    x, y = grid(n)
    u = x * 5
    col = np.floor(u).astype(np.int32)
    edge = np.minimum(u % 1, 1 - u % 1) / 5
    lip = smoothstep(.003, .008, edge)
    warp = .033 * noise(n, 9, 8801) + .017 * noise(n, 18, 8802)
    phase = x * 120 + warp * 16
    rng = np.random.default_rng(8803)
    knots = np.zeros((n, n), np.float32)
    for c in range(5):
        px = (c + rng.uniform(.24, .76)) / 5
        py = rng.uniform(0, 1)
        dx, dy = wrap_delta(x - px), wrap_delta(y - py)
        radius = np.sqrt((dx / .034) ** 2 + (dy / .074) ** 2 + .001)
        influence = np.exp(-radius ** 2 / 3)
        phase += .65 * influence * np.sin(np.arctan2(dy / .074, dx / .034) * 2)
        knots += influence * (.055 * np.sin(radius * 21) - .08 * np.exp(-radius ** 2 * 5))
    grain = .024 * np.sin(2 * np.pi * phase) + .012 * np.sin(2 * np.pi * phase * 2)
    relief = rng.uniform(.74, .86, 5).astype(np.float32)[col]
    return lip * (relief + grain + knots + .012 * fbm(n, 8804, (30, 60, 120)))


def reptile_scales(n):
    """Staggered, overlapping shield-shaped scales with raised lower rims."""
    x, y = grid(n)
    x, y = (x + .031) % 1, (y + .047) % 1
    base_row = np.floor(y * 8).astype(np.int32)
    h = np.zeros((n, n), np.float32)
    relief = np.random.default_rng(9901).uniform(.93, 1.07, (8, 10)).astype(np.float32)
    for offset in (-1, 0, 1):
        row = base_row + offset
        u = x * 10 - .5 * (row % 2)
        col = np.floor(u + .5).astype(np.int32)
        dx = (u - col) / .52
        dy = (y * 8 - row - .28) / .76
        r = dx * dx + dy * dy
        body = smoothstep(1.02, .75, r) * (.55 + .42 * np.maximum(1 - r, 0))
        rim = .13 * np.exp(-((r - .77) / .12) ** 2) * smoothstep(-.1, .7, dy)
        candidate = (body + rim) * relief[row % 8, col % 10]
        h = np.maximum(h, candidate)
    return h + .008 * noise(n, 170, 9902) * smoothstep(.1, .4, h)


def hammered_metal(n):
    """Many overlapping shallow bowls, varied hammer sizes, smooth rims."""
    rng = np.random.default_rng(10101)
    h = np.zeros((n, n), np.float32)
    # Rasterize compact periodic analytic dents only within their support.
    for _ in range(320):
        px, py = rng.random(2)
        radius = rng.uniform(.017, .056)
        depth = rng.uniform(.025, .075) * radius / .035
        stamp_periodic_bowl(h, px, py, radius, depth)
    return gaussian_filter(h, .0015 * n, mode='wrap') + .003 * noise(n, 100, 10102)


def stamp_periodic_bowl(h, px, py, radius, depth):
    n = len(h)
    ix = np.arange(int((px - radius) * n), int((px + radius) * n) + 1)
    iy = np.arange(int((py - radius) * n), int((py + radius) * n) + 1)
    dx = ((ix + .5) / n - px) / radius
    dy = ((iy + .5) / n - py) / radius
    r2 = dx[None, :] ** 2 + dy[:, None] ** 2
    patch = -depth * np.maximum(1 - r2, 0) ** 2
    h[np.ix_(iy % n, ix % n)] += patch.astype(np.float32)


def round_envelope(n, radius=.45):
    x, y = grid(n)
    r = np.sqrt((x - .5) ** 2 + (y - .5) ** 2)
    return 1 - smoothstep(radius - .045, radius, r)


def soft_round(n):
    x, y = grid(n)
    r = np.sqrt((x - .5) ** 2 + (y - .5) ** 2)
    return 1 - smoothstep(.025, .445, r)


def hard_round(n):
    x, y = grid(n)
    r = np.sqrt((x - .5) ** 2 + (y - .5) ** 2)
    boundary = .374 + .018 * noise(n, 16, 12001) + .006 * noise(n, 48, 12002)
    return 1 - smoothstep(boundary - .003, boundary + .005, r)


def chalk_grain(n):
    coarse = smoothstep(-.9, .65, fbm(n, 13001, (18, 36, 72)))
    tooth = smoothstep(-.9, .45, noise(n, 260, 13002))
    return round_envelope(n, .425) * coarse * tooth


def canvas(n):
    im = Image.new('L', (n, n))
    return im, ImageDraw.Draw(im)


def draw_path(draw, n, points, width, value=255):
    xy = [(int(x * n), int(y * n)) for x, y in points]
    draw.line(xy, fill=int(value), width=max(1, round(width * n)), joint='curve')


def dry_brush(n):
    im, draw = canvas(n)
    rng = np.random.default_rng(14001)
    for _ in range(165):
        yy = rng.normal(.50, .105)
        if not .22 < yy < .78:
            continue
        left, right = rng.uniform(.10, .28), rng.uniform(.72, .9)
        points = [(t, yy + .003 * np.sin(t * 18 + yy * 100)) for t in np.linspace(left, right, 30)]
        draw_path(draw, n, points, rng.uniform(.0008, .004), rng.uniform(95, 255))
    h = gaussian_filter(np.asarray(im, np.float32) / 255, max(.45, n * .0005))
    x, _ = grid(n)
    h *= smoothstep(.085, .22, x) * (1 - smoothstep(.72, .91, x))
    h *= smoothstep(-.55, .35, noise(n, 70, 14002))
    return h


def dab(h, px, py, radius, opacity=1., softness=.2, elongation=1.):
    """Analytic antialiased disk or ellipse, with a clipped local footprint."""
    n = len(h)
    x0, x1 = max(0, int((px - radius) * n) - 2), min(n, int((px + radius) * n) + 3)
    y0, y1 = max(0, int((py - radius * elongation) * n) - 2), min(n, int((py + radius * elongation) * n) + 3)
    if x0 >= x1 or y0 >= y1:
        return
    dx = ((np.arange(x0, x1) + .5) / n - px) / radius
    dy = ((np.arange(y0, y1) + .5) / n - py) / (radius * elongation)
    r = np.sqrt(dx[None, :] ** 2 + dy[:, None] ** 2)
    aa = max(softness, 1 / (radius * n))
    patch = opacity * (1 - smoothstep(1 - aa, 1 + aa * .1, r))
    h[y0:y1, x0:x1] = np.maximum(h[y0:y1, x0:x1], patch)


def splatter(n):
    h = np.zeros((n, n), np.float32)
    rng = np.random.default_rng(15001)
    for i in range(225):
        angle = rng.uniform(0, 2 * np.pi)
        radial = .39 * np.sqrt(rng.random())
        px, py = .5 + radial * np.cos(angle), .5 + radial * np.sin(angle)
        radius = rng.uniform(.022, .049) if i < 13 else rng.uniform(.0016, .010)
        dab(h, px, py, radius, rng.uniform(.65, 1), .12, rng.uniform(.8, 1.3))
    return h


def scratches(n):
    im, draw = canvas(n)
    rng = np.random.default_rng(16001)
    for _ in range(37):
        cx, cy = rng.uniform(.28, .72, 2)
        angle = rng.uniform(0, np.pi)
        length = rng.uniform(.07, .36)
        dx, dy = np.cos(angle) * length / 2, np.sin(angle) * length / 2
        points = [(cx - dx, cy - dy), (cx + rng.normal(0, .005), cy + rng.normal(0, .005)), (cx + dx, cy + dy)]
        draw_path(draw, n, points, rng.uniform(.0008, .0033), rng.uniform(160, 255))
    return gaussian_filter(np.asarray(im, np.float32) / 255, max(.5, .0005 * n)) * round_envelope(n, .455)


def cracks(n):
    im, draw = canvas(n)
    rng = np.random.default_rng(17001)

    def branch(px, py, angle, length, width, depth):
        segments = 18
        for j in range(segments):
            angle += rng.normal(0, .22)
            nx, ny = px + np.cos(angle) * length / segments, py + np.sin(angle) * length / segments
            if not (.075 < nx < .925 and .075 < ny < .925):
                break
            taper = (1 - j / segments) ** .7
            draw_path(draw, n, [(px, py), (nx, ny)], width * taper, 255 * (.22 + .78 * taper))
            if depth and j in (5, 10):
                branch(nx, ny, angle + rng.choice([-1, 1]) * rng.uniform(.55, 1.05), length * .48, width * .60, depth - 1)
            px, py = nx, ny

    for angle in np.linspace(0, 2 * np.pi, 6, endpoint=False):
        branch(.48, .51, angle + rng.normal(0, .15), rng.uniform(.28, .42), .007, 2)
    return gaussian_filter(np.asarray(im, np.float32) / 255, max(.5, n * .0005)) * round_envelope(n, .46)


def grunge_blotches(n):
    cloud = fbm(n, 18001, (7, 14, 28, 56), .58)
    hard = smoothstep(.03, .15, cloud)
    soft = smoothstep(-.6, .8, cloud)
    mix = smoothstep(-1, 1, noise(n, 9, 18002))
    texture = .75 + .25 * smoothstep(-1, 1, noise(n, 170, 18003))
    return (hard * mix + soft * (1 - mix)) * texture * round_envelope(n, .435)


def stipple(n):
    h = np.zeros((n, n), np.float32)
    rng = np.random.default_rng(19001)
    for _ in range(650):
        angle = rng.uniform(0, 2 * np.pi)
        radius = .415 * np.sqrt(rng.random())
        px, py = .5 + radius * np.cos(angle), .5 + radius * np.sin(angle)
        dab(h, px, py, rng.uniform(.0015, .008), rng.uniform(.65, 1), .18)
    return h * round_envelope(n, .448)


def oil_stroke(n):
    x, y = grid(n)
    center = .5 + .026 * np.sin((x - .12) * np.pi * 1.7)
    taper = 1 - smoothstep(.52, .9, x)
    width = .155 * taper + .004
    cross = np.abs(y - center) / width
    body = (1 - smoothstep(.82, 1, cross)) * smoothstep(.09, .15, x) * (1 - smoothstep(.86, .91, x))
    # Noise depends mostly on cross-stroke position, preserving long bristle
    # tracks instead of breaking the stroke into isotropic speckles.
    transverse = (y - center) * 64
    streaks = .72 + .19 * np.sin(2 * np.pi * (transverse + .06 * np.sin(x * 21)))
    streaks += .075 * np.sin(2 * np.pi * (transverse * 2.73 + .03 * np.sin(x * 14)))
    streaks += .025 * noise(n, 64, 20002)
    return body * np.clip(streaks, .12, 1)


NORMALS = {
    'Brick': brick, 'Cobblestone': cobblestone, 'HexTiles': hex_tiles,
    'Leather': leather, 'FabricWeave': fabric_weave, 'DiamondPlate': diamond_plate,
    'Concrete': concrete, 'WoodPlanks': wood_planks, 'ReptileScales': reptile_scales,
    'HammeredMetal': hammered_metal,
}
ALPHAS = {
    'SoftRound': soft_round, 'HardRound': hard_round, 'ChalkGrain': chalk_grain,
    'DryBrush': dry_brush, 'Splatter': splatter, 'Scratches': scratches,
    'Cracks': cracks, 'GrungeBlotches': grunge_blotches, 'Stipple': stipple,
    'OilStroke': oil_stroke,
}


def height_to_normal(height, strength=1.):
    """OpenGL normals: image rows run down, so green is +dH/d(image-row).

    Central differences wrap in both directions. Calibrate UV height depth to
    RMS slope .30 at strength 1, then smoothly limit extreme slopes to .80.
    This keeps fine detail legible and blue dominant at every pixel. Encoding
    zero X/Y as round(127.5) gives the required flat pixel (128,128,255).
    """
    n = len(height)
    dx = (np.roll(height, -1, 1) - np.roll(height, 1, 1)) * (n / 2)
    dy = (np.roll(height, -1, 0) - np.roll(height, 1, 0)) * (n / 2)
    rms = float(np.sqrt(np.mean(dx * dx + dy * dy)))
    depth = .30 / max(rms, 1e-12)
    dx *= -depth * strength
    dy *= depth * strength
    slope = np.sqrt(dx * dx + dy * dy)
    attenuation = .80 * np.tanh(slope / .80) / np.maximum(slope, 1e-12)
    dx *= attenuation
    dy *= attenuation
    inverse = 1 / np.sqrt(1 + dx * dx + dy * dy)
    normal = np.stack((dx * inverse, dy * inverse, inverse), axis=-1)
    encoded = np.rint(np.clip(normal * .5 + .5, 0, 1) * 255).astype(np.uint8)
    return encoded, depth


def quantize_alpha(alpha, seed):
    """8-bit L output with sub-LSB stochastic dithering to prevent contour bands."""
    alpha = np.clip(alpha, 0, None).astype(np.float32)
    alpha /= max(float(alpha.max()), 1e-12)
    # A generous exact-black margin also catches Gaussian drawing tails.
    x, y = grid(len(alpha))
    margin = np.minimum(np.minimum(x, 1 - x), np.minimum(y, 1 - y))
    alpha *= smoothstep(.035, .065, margin)
    dither = np.random.default_rng(seed).uniform(-.5, .5, alpha.shape).astype(np.float32)
    encoded = np.rint(np.clip(alpha * 255 + dither, 0, 255)).astype(np.uint8)
    return encoded


def contact_sheet(paths, destination, columns=5, thumb=252):
    label, gap = 36, 16
    rows = (len(paths) + columns - 1) // columns
    sheet = Image.new('RGB', (columns * (thumb + gap) + gap, rows * (thumb + label + gap) + gap), (24, 27, 34))
    draw = ImageDraw.Draw(sheet)
    try:
        font = ImageFont.truetype('DejaVuSans.ttf', 17)
    except OSError:
        font = ImageFont.load_default(size=17)
    for i, path in enumerate(paths):
        with Image.open(path) as image:
            # Reducing RGB normals is only for previews, never for output maps.
            tile = image.convert('RGB').resize((thumb, thumb), Image.Resampling.LANCZOS)
        xx, yy = gap + (i % columns) * (thumb + gap), gap + (i // columns) * (thumb + label + gap)
        sheet.paste(tile, (xx, yy))
        name = path.stem.replace('_Normal_2x2', ' (2x2)').replace('_Normal', '').replace('_Alpha', '')
        draw.text((xx + 5, yy + thumb + 9), name, font=font, fill=(229, 232, 240))
    sheet.save(destination)


def seam_statistics(rgb):
    f = rgb.astype(np.float32)
    # Compare actual joined boundary pixels with every ordinary adjacency.
    results = {}
    for axis, label in ((1, 'x'), (0, 'y')):
        interior = np.mean(np.abs(np.diff(f, axis=axis)), axis=2)
        seam = np.mean(np.abs(np.take(f, 0, axis=axis) - np.take(f, -1, axis=axis)), axis=1)
        interior_line_means = interior.mean(axis=0 if axis == 1 else 1)
        results[label] = {
            'seam_mean_8bit': float(seam.mean()),
            'interior_mean_8bit': float(interior.mean()),
            'interior_line_p95_8bit': float(np.percentile(interior_line_means, 95)),
            'seam_to_interior_ratio': float(seam.mean() / max(interior.mean(), .00001)),
            'seam_line_percentile': float(100 * np.mean(interior_line_means <= seam.mean())),
        }
        # Pattern boundaries can be intentionally sharper than a global mean;
        # use line distributions AND compare against continuous periodic source.
        results[label]['within_internal_line_range'] = bool(seam.mean() <= max(float(interior_line_means.max()) * 1.1, .1))
    return results


def validate_normal(path, depth):
    with Image.open(path) as im:
        assert im.mode == 'RGB'
        rgb = np.asarray(im)
    v = rgb.astype(np.float32) / 127.5 - 1
    lengths = np.sqrt(np.sum(v * v, axis=2))
    blue_dominant = np.all(rgb[:, :, 2] >= np.maximum(rgb[:, :, 0], rgb[:, :, 1]))
    result = {
        'mean_rgb': [float(c) for c in rgb.mean(axis=(0, 1))],
        'vector_length_min': float(lengths.min()), 'vector_length_max': float(lengths.max()),
        'vector_length_max_error': float(np.max(np.abs(lengths - 1))),
        'blue_dominant_every_pixel': bool(blue_dominant),
        'calibrated_uv_height_depth': depth,
        'seams': seam_statistics(rgb),
    }
    assert result['vector_length_max_error'] < .008, result
    assert blue_dominant, result
    assert abs(result['mean_rgb'][0] - 128) < 3 and abs(result['mean_rgb'][1] - 128) < 3, result
    assert result['mean_rgb'][2] > 243, result
    assert all(s['within_internal_line_range'] for s in result['seams'].values()), result
    return result


def validate_alpha(path):
    with Image.open(path) as im:
        assert im.mode == 'L'
        a = np.asarray(im)
    border = np.concatenate((a[0], a[-1], a[:, 0], a[:, -1]))
    assert a.min() == 0 and a.max() == 255
    assert not np.any(border)
    result = {'range_0_to_1': [float(a.min() / 255), float(a.max() / 255)],
              'border_max': int(border.max()), 'unique_levels': len(np.unique(a)),
              'nonzero_coverage_percent': float(np.mean(a > 0) * 100)}
    return result


def save_tiled_preview(path, destination):
    with Image.open(path) as im:
        tile = im.convert('RGB')
    n = tile.width
    tiled = Image.new('RGB', (n * 2, n * 2))
    for px, py in ((0, 0), (n, 0), (0, n), (n, n)):
        tiled.paste(tile, (px, py))
    tiled.save(destination)


def algorithm_checks():
    """Check conversion sign, exact flat color, and actual torus sampling."""
    flat, _ = height_to_normal(np.zeros((32, 32), np.float32))
    assert np.all(flat == [128, 128, 255])
    x, y = grid(128)
    h = np.broadcast_to(np.sin(2 * np.pi * y), (128, 128)).copy()
    rgb, _ = height_to_normal(h)
    assert rgb[0, 0, 1] > 128 and rgb[64, 0, 1] < 128
    return {'flat_pixel': [128, 128, 255], 'opengl_green_sign': 'PASS',
            'wrap_gradients': 'central difference using numpy.roll'}


def periodic_extension_checks(name, function, size=256):
    """Evaluate a real repeated height field, then differentiate its interior.

    Compare a crop crossing the join with normals generated using wrap gradients.
    This tests the 2x2 conversion boundary, not merely first-vs-last equality.
    """
    h = function(size).astype(np.float32)
    n1, _ = height_to_normal(h)
    n2, _ = height_to_normal(np.tile(h, (2, 2)))
    # Doubling UV derivative and halving calibrated depth cancel exactly.
    error = int(np.max(np.abs(n2.astype(np.int16) - np.tile(n1, (2, 2, 1)).astype(np.int16))))
    assert error <= 1, (name, error)
    return {'normal_vs_2x2_height_conversion_max_lsb': error}


def write_report(output, report):
    (output / 'validation.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    lines = ['# Generated texture checks', '',
             f"Resolution: {report['size']} x {report['size']}. All 20 PNGs reopened and checked.", '',
             '## Normal maps', '',
             'Seam difference is the mean absolute RGB change between adjacent pixels at the join, in 8-bit units. '
             'Interior is the mean over ordinary neighboring pixels. An intentional mortar joint can exceed the global mean; '
             'the internal scanline range and the tiled height conversion provide additional context.', '',
             '| Map | Mean RGB | Max length error | X seam / interior | Y seam / interior | 2x2 conversion max LSB |',
             '|---|---|---:|---:|---:|---:|']
    for name, r in report['normals'].items():
        sx, sy = r['seams']['x'], r['seams']['y']
        mean = ', '.join(f'{c:.2f}' for c in r['mean_rgb'])
        lines.append(f"| {name} | {mean} | {r['vector_length_max_error']:.5f} | {sx['seam_mean_8bit']:.3f} / {sx['interior_mean_8bit']:.3f} | {sy['seam_mean_8bit']:.3f} / {sy['interior_mean_8bit']:.3f} | {r['normal_vs_2x2_height_conversion_max_lsb']} |")
    lines += ['', 'Every pixel has blue >= red and green. Flat conversion is exactly RGB (128,128,255). '
              'Green sign passes an analytic Y ramp check. Unit length deviations are from 8-bit quantization.', '',
              '## Alpha maps', '', '| Map | Range | Border maximum | Unique gray levels | Coverage |',
              '|---|---|---:|---:|---:|']
    for name, r in report['alphas'].items():
        lines.append(f"| {name} | 0..1 | {r['border_max']} | {r['unique_levels']} | {r['nonzero_coverage_percent']:.1f}% |")
    lines += ['', 'Sub-LSB deterministic dither breaks up smooth 8-bit contour bands. '
              'All alphas remain single-channel, 8-bit L PNGs with an exact-black 3.5% perimeter margin.', '',
              'SHA-256 file fingerprints and full seam statistics are recorded in validation.json.', '']
    (output / 'CHECKS.md').write_text('\n'.join(lines), encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--size', type=int, default=1024, choices=(256, 512, 1024, 2048, 4096), help='Output pixels per side; 256/512 also allowed for quick previews.')
    parser.add_argument('--output', type=Path, default=Path('output'))
    parser.add_argument('--strength', type=float, default=1., help='Normal slope multiplier before smooth limiting (default 1).')
    args = parser.parse_args()
    if args.strength <= 0:
        parser.error('--strength must be positive')
    output = args.output
    textures, alphas, previews = output / 'textures', output / 'alphas', output / 'seam_previews'
    for directory in (textures, alphas, previews):
        directory.mkdir(parents=True, exist_ok=True)
    report = {'size': args.size, 'strength': args.strength, 'algorithm': algorithm_checks(), 'normals': {}, 'alphas': {}, 'sha256': {}}
    normal_paths, alpha_paths = [], []
    for name, function in NORMALS.items():
        start = time.perf_counter()
        height = function(args.size).astype(np.float32)
        assert height.shape == (args.size, args.size) and np.all(np.isfinite(height))
        rgb, depth = height_to_normal(height, args.strength)
        path = textures / f'{name}_Normal.png'
        Image.fromarray(rgb).save(path)
        r = validate_normal(path, depth)
        r.update(periodic_extension_checks(name, function))
        report['normals'][name] = r
        normal_paths.append(path)
        if name in ('Brick', 'Cobblestone', 'HexTiles', 'WoodPlanks'):
            save_tiled_preview(path, previews / f'{name}_Normal_2x2.png')
        print(f'{path}: checked ({time.perf_counter() - start:.1f}s)', flush=True)
        del height, rgb
    for index, (name, function) in enumerate(ALPHAS.items()):
        start = time.perf_counter()
        alpha = function(args.size)
        assert alpha.shape == (args.size, args.size) and np.all(np.isfinite(alpha))
        encoded = quantize_alpha(alpha, 31000 + index)
        path = alphas / f'{name}_Alpha.png'
        Image.fromarray(encoded).save(path)
        report['alphas'][name] = validate_alpha(path)
        alpha_paths.append(path)
        print(f'{path}: checked ({time.perf_counter() - start:.1f}s)', flush=True)
        del alpha, encoded
    contact_sheet(normal_paths, output / 'preview_normals.png')
    contact_sheet(alpha_paths, output / 'preview_alphas.png')
    contact_sheet([previews / f'{name}_Normal_2x2.png' for name in ('Brick', 'Cobblestone', 'HexTiles', 'WoodPlanks')],
                  output / 'preview_seams.png', columns=4, thumb=360)
    for path in normal_paths + alpha_paths:
        report['sha256'][str(path.relative_to(output)).replace('\\', '/')] = hashlib.sha256(path.read_bytes()).hexdigest()
    write_report(output, report)
    print('Done. Contact sheets, four 2x2 previews, and validation reports saved.', flush=True)


if __name__ == '__main__':
    main()
