# Generated texture checks

Resolution: 1024 x 1024. All 20 PNGs reopened and checked.

## Normal maps

Seam difference is the mean absolute RGB change between adjacent pixels at the join, in 8-bit units. Interior is the mean over ordinary neighboring pixels. An intentional mortar joint can exceed the global mean; the internal scanline range and the tiled height conversion provide additional context.

| Map | Mean RGB | Max length error | X seam / interior | Y seam / interior | 2x2 conversion max LSB |
|---|---|---:|---:|---:|---:|
| Brick | 127.54, 127.51, 252.59 | 0.00578 | 0.152 / 0.782 | 0.000 / 1.217 | 0 |
| Cobblestone | 127.52, 127.51, 252.13 | 0.00597 | 1.966 / 1.231 | 2.507 / 1.238 | 0 |
| HexTiles | 127.53, 127.53, 252.60 | 0.00615 | 0.678 / 1.315 | 0.123 / 1.269 | 0 |
| Leather | 127.50, 127.50, 251.23 | 0.00609 | 12.233 / 7.083 | 12.435 / 7.018 | 0 |
| FabricWeave | 127.50, 127.50, 250.68 | 0.00554 | 6.656 / 3.883 | 6.672 / 3.883 | 0 |
| DiamondPlate | 127.50, 127.50, 254.02 | 0.00560 | 0.902 / 0.811 | 0.886 / 0.811 | 0 |
| Concrete | 127.52, 127.50, 251.14 | 0.00597 | 3.250 / 2.779 | 3.021 / 2.751 | 0 |
| WoodPlanks | 127.63, 127.51, 253.21 | 0.00529 | 0.000 / 4.661 | 0.422 / 0.434 | 0 |
| ReptileScales | 127.50, 127.73, 252.91 | 0.00584 | 1.068 / 1.755 | 0.588 / 1.026 | 0 |
| HammeredMetal | 127.48, 127.49, 250.94 | 0.00615 | 1.310 / 1.074 | 1.204 / 1.068 | 0 |

Every pixel has blue >= red and green. Flat conversion is exactly RGB (128,128,255). Green sign passes an analytic Y ramp check. Unit length deviations are from 8-bit quantization.

## Alpha maps

| Map | Range | Border maximum | Unique gray levels | Coverage |
|---|---|---:|---:|---:|
| SoftRound | 0..1 | 0 | 256 | 59.4% |
| HardRound | 0..1 | 0 | 256 | 45.2% |
| ChalkGrain | 0..1 | 0 | 256 | 38.9% |
| DryBrush | 0..1 | 0 | 256 | 14.6% |
| Splatter | 0..1 | 0 | 256 | 7.1% |
| Scratches | 0..1 | 0 | 227 | 3.5% |
| Cracks | 0..1 | 0 | 253 | 3.0% |
| GrungeBlotches | 0..1 | 0 | 256 | 41.3% |
| Stipple | 0..1 | 0 | 256 | 5.2% |
| OilStroke | 0..1 | 0 | 256 | 19.7% |

Sub-LSB deterministic dither breaks up smooth 8-bit contour bands. All alphas remain single-channel, 8-bit L PNGs with an exact-black 3.5% perimeter margin.

SHA-256 file fingerprints and full seam statistics are recorded in validation.json.
